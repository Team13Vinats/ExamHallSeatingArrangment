<?php include('head.php');?>
<?php include('header.php');?>

<?php include('sidebar.php');?>   
   
        
        <div class="page-wrapper">
            
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-primary">Blank</h3> </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">Blank</li>
                    </ol>
                </div>
            </div>
           
            <div class="container-fluid">
               
        
                        <p>Page working</p>
                     
        </div>
           
            <?php include('footer.php');?>